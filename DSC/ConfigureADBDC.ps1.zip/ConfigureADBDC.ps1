﻿configuration ConfigureADBDC
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xPendingReboot

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        
        # xFirewall ADWSTCPIn
        # {
        #     Name = 'ADWSTCPIn'
        #     DisplayName = 'Active Directory Web Services (TCP-in)'
        #     Direction = 'Inbound'
        #     Access = 'Allow'
        #     LocalPort = ('9389')
        #     Protocol = 'TCP'
        #     Profile = 'Any'
        #     State = 'Enabled'
        # }

        # xFirewall ADWSTCPOut
        # {
        #     Name = 'ADWSTCPOut'
        #     DisplayName = 'Active Directory Web Services (TCP-out)'
        #     Direction = 'Outbound'
        #     Access = 'Allow'
        #     RemotePort = ('9389')
        #     Protocol = 'TCP'
        #     Profile = 'Any'
        #     State = 'Enabled'
        #     DependsOn = '[xFirewall]ADWSTCPIn'
        # }
        
        # xWaitForADDomain DscForestWait
        # {
        #     DomainName = $DomainName
        #     DomainUserCredential= $DomainCreds
        #     RetryCount = $RetryCount
        #     RetryIntervalSec = $RetryIntervalSec
        #     DependsOn = '[xFirewall]ADWSTCPOut'
        # }

        
        Script BDC
        {
            GetScript = {
                Return @{
                    Result = [string]$(Get-ADDomain)
                }
            }
            TestScript = {
                Get-ADDomain | Out-Null
                #try {
                #    Get-ADDomain | Out-Null
                #}
                #catch {
                #    return $false
                #}
                return $true
            }
            SetScript = {
                try {
                    Get-ADDomain | Out-Null
                } catch {
                    Install-ADDSDomainController -DomainName $using:DomainName -InstallDns:$true -Credential $using:DomainCreds -NoRebootOnCompletion -SafeModeAdministratorPassword $using:DomainCreds.Password -Force
                }
            }
            # DependsOn = "[xWaitForADDomain]DscForestWait"
        }

        # xADDomainController BDC
        # {
        #     DomainName = $DomainName
        #     DomainAdministratorCredential = $DomainCreds
        #     SafemodeAdministratorPassword = $DomainCreds
        #     DatabasePath = "F:\NTDS"
        #     LogPath = "F:\NTDS"
        #     SysvolPath = "F:\SYSVOL"
        #     DependsOn = "[xWaitForADDomain]DscForestWait"
        # }
<#
        Script UpdateDNSForwarder
        {
            SetScript =
            {
                Write-Verbose -Verbose "Getting DNS forwarding rule..."
                $dnsFwdRule = Get-DnsServerForwarder -Verbose
                if ($dnsFwdRule)
                {
                    Write-Verbose -Verbose "Removing DNS forwarding rule"
                    Remove-DnsServerForwarder -IPAddress $dnsFwdRule.IPAddress -Force -Verbose
                }
                Write-Verbose -Verbose "End of UpdateDNSForwarder script..."
            }
            GetScript =  { @{} }
            TestScript = { $false}
            DependsOn = "[xADDomainController]BDC"
        }
#>
        xPendingReboot RebootAfterPromotion {
            Name = "RebootAfterDCPromotion"
            DependsOn = "[Script]BDC"
            # DependsOn = "[xADDomainController]BDC"
        }

    }
}
