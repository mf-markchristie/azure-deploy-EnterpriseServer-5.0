﻿configuration CreateADPDC
{
   param
   (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Servicecreds,

        [Parameter(Mandatory)]
        [String]$LBName,

        [Parameter(Mandatory)]
        [String]$LBIp,

        [Parameter(Mandatory)]
        [String]$RedisCacheName,

        [Parameter(Mandatory)]
        [String]$RedisIp,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    $Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InterfaceAlias=$($Interface.Name)
    $ServiceUsername=$Servicecreds.Username
    $LoadBalancerFQ="MSSQLSvc/$LBName.$DomainName" + ":1433"

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature DNS
        {
            Ensure = "Present"
            Name = "DNS"
        }

        Script EnableDNSDiags
        {
      	    SetScript = {
                Set-DnsServerDiagnostics -All $true
                Write-Verbose -Verbose "Enabling DNS client diagnostics"
            }
            GetScript =  { @{} }
            TestScript = { $false }
            DependsOn = "[WindowsFeature]DNS"
        }

        WindowsFeature DnsTools
        {
            Ensure = "Present"
            Name = "RSAT-DNS-Server"
            DependsOn = "[WindowsFeature]DNS"
        }

        xDnsServerAddress DnsServerAddress
        {
            Address        = '127.0.0.1'
            InterfaceAlias = $InterfaceAlias
            AddressFamily  = 'IPv4'
            DependsOn = "[WindowsFeature]DNS"
        }

        xWaitforDisk Disk2
        {
            DiskNumber = 2
            RetryIntervalSec =$RetryIntervalSec
            RetryCount = $RetryCount
        }

        xDisk ADDataDisk {
            DiskNumber = 2
            DriveLetter = "F"
            DependsOn = "[xWaitForDisk]Disk2"
        }

        WindowsFeature ADDSInstall
        {
            Ensure = "Present"
            Name = "AD-Domain-Services"
            DependsOn="[WindowsFeature]DNS"
        }

        WindowsFeature ADDSTools
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = "[WindowsFeature]ADDSInstall"
        }

        WindowsFeature ADAdminCenter
        {
            Ensure = "Present"
            Name = "RSAT-AD-AdminCenter"
            DependsOn = "[WindowsFeature]ADDSTools"
        }

        xADDomain FirstDS
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = @("[WindowsFeature]ADDSInstall", "[xDisk]ADDataDisk")
        }

        xADUser FirstUser
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            UserName = $Servicecreds.Username
            Password = $Servicecreds
            Ensure = "Present"
            Description = "MF Service Account User"
            Enabled = $true
            PasswordNeverExpires = $true
            DependsOn = "[xADDomain]FirstDS"
        }

        Script AddLbRecord
        {
            GetScript = {
                Return @{
                    Result = [string]$(Get-DnsServerResourceRecord -Name $using:LBName -ZoneName $using:DomainName -ErrorAction SilentlyContinue -RRType A)
                }
            }
            TestScript = {
                $ARecord=Get-DnsServerResourceRecord -Name $using:LBName -ZoneName $using:DomainName -ErrorAction SilentlyContinue -RRType A
                if ($Arecord) {
                    Return $true
                } else {
                    Return $false
                }
            }
            SetScript = {
                Add-DnsServerResourceRecordA -Name $using:LBName -ZoneName $using:DomainName -IPv4Address $using:LbIp
                setspn -A $using:LoadBalancerFQ $using:DomainName\$using:ServiceUsername
            }
            Credential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[xADUser]FirstUser"
        }

        Script AddRedisRecord
        {
            GetScript = {
                Return @{
                    Result = [string]$(Get-DnsServerResourceRecord -Name $using:RedisCacheName -ZoneName $using:DomainName -ErrorAction SilentlyContinue -RRType A)
                }
            }
            TestScript = {
                $ARecord=Get-DnsServerResourceRecord -Name $using:RedisCacheName -ZoneName $using:DomainName -ErrorAction SilentlyContinue -RRType A
                if ($Arecord) {
                    Return $true
                } else {
                    Return $false
                }
            }
            SetScript = {
                Add-DnsServerResourceRecordA -Name $using:RedisCacheName -ZoneName $using:DomainName -IPv4Address $using:RedisIp
            }
            Credential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            DependsOn = "[Script]AddLbRecord"
        }

        xFirewall ADWSTCP
        {
            Name        = 'ADWSTCP'
            DisplayName = 'Active Directory Web Services (TCP-in)'
            Action      = 'Allow'
            Direction   = 'Inbound'
            LocalPort   = ('9389')
            Protocol    = 'TCP'
            Profile     = 'Any'
            Enabled     = 'True'
        }

        xPendingReboot RebootAfterPromotion{
            Name = "RebootAfterPromotion"
            DependsOn = "[xFirewall]ADWSTCP"
        }

   }
}