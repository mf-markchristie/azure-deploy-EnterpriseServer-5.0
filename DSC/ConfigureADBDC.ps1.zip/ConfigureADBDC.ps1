﻿configuration ConfigureADBDC
{
   param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xActiveDirectory, xNetworking, xPendingReboot

    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    #$AdminUser = $Admincreds.UserName
    #$AdminPass = $Admincreds.GetNetworkCredential().Password

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        
        # xFirewall ADWSTCPIn
        # {
        #     Name = 'ADWSTCPIn'
        #     DisplayName = 'Active Directory Web Services (TCP-in)'
        #     Direction = 'Inbound'
        #     Access = 'Allow'
        #     LocalPort = ('9389')
        #     Protocol = 'TCP'
        #     Profile = 'Any'
        #     State = 'Enabled'
        # }

        # xFirewall ADWSTCPOut
        # {
        #     Name = 'ADWSTCPOut'
        #     DisplayName = 'Active Directory Web Services (TCP-out)'
        #     Direction = 'Outbound'
        #     Access = 'Allow'
        #     RemotePort = ('9389')
        #     Protocol = 'TCP'
        #     Profile = 'Any'
        #     State = 'Enabled'
        #     DependsOn = '[xFirewall]ADWSTCPIn'
        # }
        
        xWaitForADDomain DscForestWait
        {
            DomainName = $DomainName
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount
            RetryIntervalSec = $RetryIntervalSec
            DependsOn = '[xFirewall]ADWSTCPOut'
        }

        
        #Script BDC
        #{
        #    GetScript = {
        #        Return @{
        #            Result = [string]$(Get-ADDomain)
        #        }
        #    }
        #    TestScript = {
        #        try {
        #            Get-ADDomain | Out-Null
        #        }
        #        catch {
        #            return $false
        #        }
        #        return $true
        #    }
        #    SetScript = {
        #        try {
        #            Get-ADDomain | Out-Null
        #        } catch {
        #            mkdir c:\tmp
        #            Write-Host "User: ${$using:DomainName}\${$using:AdminUser}" | Out-File -FilePath "C:\tmp\dbg.txt"
        #            Write-Host "Pass: $using:AdminPass" | Out-File -FilePath "C:\tmp\dbg.txt" -Append
        #            $DomainPass = ConvertTo-SecureString $using:AdminPass -AsPlainText -Force
        #            [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${$using:DomainName}\${$using:AdminUser}", $DomainPass)
        #            Install-ADDSDomainController -DomainName $using:DomainName -InstallDns:$true -Credential $DomainCreds -NoRebootOnCompletion -SafeModeAdministratorPassword $DomainPass -Force
        #        }
        #    }
        #    Credential = $Admincreds
        #    PsDscRunAsCredential = $Admincreds
        #    # DependsOn = "[xWaitForADDomain]DscForestWait"
        #}

        xADDomainController BDC
        {
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = "[xWaitForADDomain]DscForestWait"
            PsDscRunAsCredential = $Admincreds
        }

        xPendingReboot RebootAfterPromotion {
            Name = "RebootAfterDCPromotion"
            #DependsOn = "[Script]BDC"
            DependsOn = "[xADDomainController]BDC"
        }

    }
}
